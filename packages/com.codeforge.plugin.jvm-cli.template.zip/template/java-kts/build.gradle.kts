plugins {
    // Java 17, application und JUnit – siehe build-logic
    id("app.java.application")
}

application { mainClass.set("{{packageName}}.Main") }
