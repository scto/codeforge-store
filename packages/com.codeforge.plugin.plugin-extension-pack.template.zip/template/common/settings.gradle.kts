rootProject.name = "{{projectName}}"
